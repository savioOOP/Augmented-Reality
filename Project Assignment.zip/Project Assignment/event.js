AFRAME.registerComponent('markerhandler', {

    init: function() {
        
        // First Marker and Model
        const marker1 = document.querySelector("#marker1");
        var entity1 = document.querySelector("#box1");
        
        // Second Marker and Model
        const marker2 = document.querySelector("#marker2");
        var entity2 = document.querySelector("#box2");
        
        // Third Marker and Model
        const marker3 = document.querySelector("#marker3");
        var entity3 = document.querySelector("#box3");

        // Car and Motorcycle Texts
        var carText = document.querySelector("#text1");
        var motorcycleText = document.querySelector("#text2");
        

        // Marker 1
        marker1.addEventListener('mouseenter', function(ev, target){
            entity1.setAttribute("scale", "0.03 0.03 0.03");
        }); 
        
        marker1.addEventListener('mouseleave', function(ev, target){
            entity1.setAttribute("scale", "0.02 0.02 0.02");
        });
        
        // Clicking the Car Model reveals the text
        entity1.addEventListener('click', function(ev, target){
            carText.setAttribute("visible",true);
        });
        
        // Marker 2
         marker2.addEventListener('mouseenter', function(ev, target){
            entity2.setAttribute("scale", "0.05 0.05 0.05");
        });
        
         marker2.addEventListener('mouseleave', function(ev, target){
            entity2.setAttribute("scale", "0.04 0.04 0.04");
        });
        
        // Clicking the Motorcycle Model reveals the text
        entity2.addEventListener('click', function(ev, target){
            motorcycleText.setAttribute("visible",true);
        });
        
        // Marker 3
        marker3.addEventListener('mouseenter', function(ev, target){
            entity3.setAttribute("scale", "0.2 0.2 0.2");
        });
        
        marker3.addEventListener('mouseleave', function(ev, target){
            entity3.setAttribute("scale", "0.1 0.1 0.1");
        });
        
        // Clicking the Van Model changes its colour (Does not work)
        entity3.addEventListener('click', function(ev, target){
            entity3.setAttribute("material", "color: black");
        });
  
}});